export default function UserPageLoading() {
  return (
    <div className="align-self-center justify-self-center">User loading...</div>
  );
}

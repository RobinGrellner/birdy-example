"use client";
export default function UserPageError() {
  return (
    <div className="align-self-center justify-self-center">User not found</div>
  );
}

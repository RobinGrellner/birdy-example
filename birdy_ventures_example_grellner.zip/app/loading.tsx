//TODO Implement loading site
export default function UserPageLoading() {
  return (
    <>
      <div className="wd-full bg-amber-400"> User Overview loading </div>
    </>
  );
}

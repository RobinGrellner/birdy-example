"use client";

export default function BaseErrorPage() {
  return (
    <div className="align-self-center justify-self-center">
      Something went wrong!
    </div>
  );
}
